//
//  SecondViewController.m
//  test
//
//  Created by Strong, Shadrian B. on 7/22/14.
//  Copyright (c) 2014 ALIS. All rights reserved.
//

#import "SecondViewController.h"
#import <Social/Social.h>
#import <MapKit/MapKit.h>
#import "MapViewController.h"

@interface SecondViewController ()
@end

@implementation SecondViewController
//@synthesize aerosolOpticalDepth;
//@synthesize mapView;


- (void)viewDidLoad
{
    [super viewDidLoad];
    //mapView.showsUserLocation = YES;
    //self.mapView.delegate = self;
    // Do any additional setup after loading the view.
    self.AOD.text= [NSString stringWithFormat: @"%f", self.aodText];
    self.AIRMASS.text= [NSString stringWithFormat: @"%f", (double)self.airMass];
    self.timeNow.text=self.timeText;
    self.AQI.text = self.aqiText;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)postToFacebook:(id)sender {
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        [controller setInitialText:@"The air quality here is: "];
        [self presentViewController:controller animated:YES completion:Nil];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
/*- (IBAction)zoomIn:(id)sender {
    MKUserLocation *userLocation = _mapView.userLocation;
    MKCoordinateRegion region =
    MKCoordinateRegionMakeWithDistance (
                                        userLocation.location.coordinate, 20000, 20000);
    [_mapView setRegion:region animated:NO];
}
*/




- (IBAction)startOver:(id)sender {
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue  sender:(id)sender{
    
    MapViewController *transferViewController = segue.destinationViewController;
    
    NSLog(@"prepareForSegue: %@", segue.identifier);
    if([segue.identifier isEqualToString:@"mapSegue"])
    {
        transferViewController.mapAOD=self.AOD.text; //@"0.01"; // &(aerosolOpticalDepth);  //@"-1.0";
        
    }/*else if([segue.identifier isEqualToString:@"johnSegue"]){
      
      }*/
    
}

@end
