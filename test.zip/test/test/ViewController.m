//
//  ViewController.m
//  test
//
//  Created by Strong, Shadrian B. on 7/12/14.
//  Copyright (c) 2014 ALIS. All rights reserved.
//

#import "ViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <QuartzCore/QuartzCore.h>
#import "ImageProcessor.h"
#import "UIImage+OrientationFix.h"
#import <CoreLocation/CoreLocation.h>
#import "SecondViewController.h"


//@interface ViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
//@end

//----for main viewcontroller
int x;
@interface ViewController () <CLLocationManagerDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIGestureRecognizerDelegate, ImageProcessorDelegate>
//extern int x;
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
//------from 'SpookCam'
//@property (strong, nonatomic) CLLocationManager *locationManager;
@property (strong, nonatomic) UIImagePickerController * imagePickerController;
@property (strong, nonatomic) UIImage * workingImage;
//end from SpookCam
//------for adaptive aperature
@property (nonatomic) CGFloat circleRadius;
@property (nonatomic) CGPoint circleCenter;
@property (nonatomic, weak) CAShapeLayer *maskLayer;
@property (nonatomic, weak) CAShapeLayer *circleLayer;

@property (nonatomic, weak) UIPinchGestureRecognizer *pinch;
@property (nonatomic, weak) UIPanGestureRecognizer   *pan;
//end adaptive aperture

@end
@implementation ViewController
@synthesize aerosolOpticalDepth;
@synthesize locationManager=_locationManager;
//{
//    AVCaptureSession *_captureSession;
//   AVCaptureVideoDataOutput *_dataOutput;

//   CALayer *_customPreviewLayer;
//}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // ** Don't forget to add NSLocationWhenInUseUsageDescription in MyApp-Info.plist and give it a string
   self.locationManager=[[CLLocationManager alloc] init];

    
  //  self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    // Check for iOS 8. Without this guard the code will crash with "unknown selector" on iOS 7.
    if ([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [self.locationManager requestWhenInUseAuthorization];
    }
    [self.locationManager startUpdatingLocation];
    
    // create layer mask for the image
    //[self setupCameraSession];
    
    // [_captureSession startRunning];
    CAShapeLayer *maskLayer = [CAShapeLayer layer];
    self.imageView.layer.mask = maskLayer;
    self.maskLayer = maskLayer;
    
    // create shape layer for circle we'll draw on top of image (the boundary of the circle)
    
    CAShapeLayer *circleLayer = [CAShapeLayer layer];
    circleLayer.lineWidth = 3.0;
    circleLayer.fillColor = [[UIColor clearColor] CGColor];
    circleLayer.strokeColor = [[UIColor blackColor] CGColor];
    [self.imageView.layer addSublayer:circleLayer];
    self.circleLayer = circleLayer;
    
    // create circle path
    
    [self updateCirclePathAtLocation:CGPointMake(self.view.bounds.size.width / 2.0, self.view.bounds.size.height / 2.0) radius:self.view.bounds.size.width * 0.30];
    
    // create pan gesture
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    pan.delegate = self;
    [self.imageView addGestureRecognizer:pan];
    self.imageView.userInteractionEnabled = YES;
    self.pan = pan;
    
    // create pan gesture
    
    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinch:)];
    pinch.delegate = self;
    [self.view addGestureRecognizer:pinch];
    self.pinch = pinch;
    //self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.distanceFilter = kCLDistanceFilterNone;
    self.locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    [self.locationManager startUpdatingLocation];
        
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    NSLog(@"%@", [locations lastObject]);
   
}


- (void)requestAlwaysAuthorization
{
    CLAuthorizationStatus status = [CLLocationManager authorizationStatus];
    
    // If the status is denied or only granted for when in use, display an alert
    if (status == kCLAuthorizationStatusAuthorizedWhenInUse || status == kCLAuthorizationStatusDenied) {
        NSString *title;
        title = (status == kCLAuthorizationStatusDenied) ? @"Location services are off" : @"Background location is not enabled";
        NSString *message = @"To use background location you must turn on 'Always' in the Location Services Settings";
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                            message:message
                                                           delegate:self
                                                  cancelButtonTitle:@"Cancel"
                                                  otherButtonTitles:@"Settings", nil];
        [alertView show];
    }
    // The user has not enabled any location services. Request background authorization.
    else if (status == kCLAuthorizationStatusNotDetermined) {
        [self.locationManager requestAlwaysAuthorization];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        // Send the user to the Settings for this app
        NSURL *settingsURL = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        [[UIApplication sharedApplication] openURL:settingsURL];
    }
}



- (void)updateCirclePathAtLocation:(CGPoint)location radius:(CGFloat)radius
{
    self.circleCenter = location;
    self.circleRadius = radius;
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path addArcWithCenter:self.circleCenter
                    radius:self.circleRadius
                startAngle:0.0
                  endAngle:M_PI * 2.0
                 clockwise:YES];
    
    self.maskLayer.path = [path CGPath];
    self.circleLayer.path = [path CGPath];
}


- (IBAction)didTouchUpInsideSaveButton:(id)sender
{
    NSString *documentsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *path = [documentsPath stringByAppendingPathComponent:@"image.png"];
    
    CGFloat scale  = [[self.imageView.window screen] scale];
    CGFloat radius = self.circleRadius * scale;
    CGPoint center = CGPointMake(self.circleCenter.x * scale, self.circleCenter.y * scale);
    
    CGRect frame = CGRectMake(center.x - radius,
                              center.y - radius,
                              radius * 2.0,
                              radius * 2.0);
    
    // temporarily remove the circleLayer
    
    CALayer *circleLayer = self.circleLayer;
    [self.circleLayer removeFromSuperlayer];
    
    // render the clipped image
    
    UIGraphicsBeginImageContextWithOptions(self.imageView.frame.size, NO, 0.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    if ([self.imageView respondsToSelector:@selector(drawViewHierarchyInRect:afterScreenUpdates:)])
    {
        // if iOS 7, just draw it
        
        [self.imageView drawViewHierarchyInRect:self.imageView.bounds afterScreenUpdates:YES];
    }
    else
    {
        // if pre iOS 7, manually clip it
        
        CGContextAddArc(context, self.circleCenter.x, self.circleCenter.y, self.circleRadius, 0, M_PI * 2.0, YES);
        CGContextClip(context);
        [self.imageView.layer renderInContext:context];
    }
    
    // capture the image and close the context
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    // add the circleLayer back
    
    [self.imageView.layer addSublayer:circleLayer];
    
    // crop the image
    
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], frame);
    UIImage *croppedImage = [UIImage imageWithCGImage:imageRef];
    
    // save the image
    
    NSData *data = UIImagePNGRepresentation(croppedImage);
    [data writeToFile:path atomically:YES];
    
    // tell the user we're done
    
    [[[UIAlertView alloc] initWithTitle:nil message:@"Saved" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil] show];
    
    //UIColor *c = [self getRGBAsFromImage:data atX:0 atY:0 count:1];

    UIImage * myCroppedImage = [UIImage imageWithContentsOfFile:path];
    // don't display -- weird skewing
    //self.imageView.image = myCroppedImage;
    [self setupWithImage:myCroppedImage];
    
}



//Get Pixel data: not sure how to implement this yet?
/*- (UIColor*)getRGBAsFromImage:(UIImage*)image atX:(int)xx andY:(int)yy count:(int)count
{
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:count];
    
    // First get the image into your data buffer
    CGImageRef imageRef = [image CGImage];
    NSUInteger width = CGImageGetWidth(imageRef);
    NSUInteger height = CGImageGetHeight(imageRef);
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    unsigned char *rawData = (unsigned char*) calloc(height * width * 4, sizeof(unsigned char));
    NSUInteger bytesPerPixel = 4;
    NSUInteger bytesPerRow = bytesPerPixel * width;
    NSUInteger bitsPerComponent = 8;
    CGContextRef context = CGBitmapContextCreate(rawData, width, height,
                                                 bitsPerComponent, bytesPerRow, colorSpace,
                                                 kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(colorSpace);
    
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), imageRef);
    CGContextRelease(context);
    
    // Now your rawData contains the image data in the RGBA8888 pixel format.
    int byteIndex = (bytesPerRow * yy) + xx * bytesPerPixel;
    for (int ii = 0 ; ii < count ; ++ii)
    {
        CGFloat red   = (rawData[byteIndex]     * 1.0) / 255.0;
        CGFloat green = (rawData[byteIndex + 1] * 1.0) / 255.0;
        CGFloat blue  = (rawData[byteIndex + 2] * 1.0) / 255.0;
        CGFloat alpha = (rawData[byteIndex + 3] * 1.0) / 255.0;
        byteIndex += 4;
        
        UIColor *acolor = [UIColor colorWithRed:red green:green blue:blue alpha:alpha];
        [result addObject:acolor];
    }
    
    free(rawData);
    
    return result;
}
 */

#pragma mark - Gesture recognizers

- (void)handlePan:(UIPanGestureRecognizer *)gesture
{
    static CGPoint oldCenter;
    CGPoint tranlation = [gesture translationInView:gesture.view];
    
    if (gesture.state == UIGestureRecognizerStateBegan)
    {
        oldCenter = self.circleCenter;
    }
    
    CGPoint newCenter = CGPointMake(oldCenter.x + tranlation.x, oldCenter.y + tranlation.y);
    
    [self updateCirclePathAtLocation:newCenter radius:self.circleRadius];
}

- (void)handlePinch:(UIPinchGestureRecognizer *)gesture
{
    static CGFloat oldRadius;
    CGFloat scale = [gesture scale];
    
    if (gesture.state == UIGestureRecognizerStateBegan)
    {
        oldRadius = self.circleRadius;
    }
    
    CGFloat newRadius = oldRadius * scale;
    
    [self updateCirclePathAtLocation:self.circleCenter radius:newRadius];
}


#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    if ((gestureRecognizer == self.pan   && otherGestureRecognizer == self.pinch) ||
        (gestureRecognizer == self.pinch && otherGestureRecognizer == self.pan))
    {
        return YES;
    }
    
    return NO;
}



-(void)viewDidAppear:(BOOL)animated{
    [self.navigationItem setHidesBackButton:YES animated:NO];
}


- (IBAction)takePhoto:(UIButton *)sender {
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    
    [self presentViewController:picker animated:YES completion:NULL];
    
}

#pragma mark UIImagePickerControllerDelegate

-(void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSString *mediaType = info[UIImagePickerControllerMediaType];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    if ([mediaType isEqualToString:(NSString *)kUTTypeImage]) {
        UIImage *image = info[UIImagePickerControllerOriginalImage];
        
        _imageView.image = image;
        if (_newMedia)
            UIImageWriteToSavedPhotosAlbum(image,
                                           self,
                                           @selector(image:finishedSavingWithError:contextInfo:),
                                           nil);
    }
    else if ([mediaType isEqualToString:(NSString *)kUTTypeMovie])
    {
        // Code here to support video if enabled
    }
}

-(void)image:(UIImage *)image
finishedSavingWithError:(NSError *)error
 contextInfo:(void *)contextInfo
{
    if (error) {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle: @"Save failed"
                              message: @"Failed to save image"
                              delegate: nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
        [alert show];
    }
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}



//SpookCam
- (void)setupWithImage:(UIImage*)image {
    UIImage * fixedImage = [image imageWithFixedOrientation];
    self.workingImage = fixedImage;
    self.imageView.image = fixedImage;
    
    // Commence with processing!
    x = [self logPixelsOfImage:fixedImage];
   // [self logPixelsOfImage:fixedImage];
  //  sumColorOut = self.sumColor
    
}

- (int)logPixelsOfImage:(UIImage*)image  {
    // 1. Get pixels of image
    CGImageRef inputCGImage = [image CGImage];
    NSUInteger width = CGImageGetWidth(inputCGImage);
    NSUInteger height = CGImageGetHeight(inputCGImage);
    
    NSUInteger bytesPerPixel = 4;
    NSUInteger bytesPerRow = bytesPerPixel * width;
    NSUInteger bitsPerComponent = 8;
    
    UInt32 * pixels;
    pixels = (UInt32 *) calloc(height * width, sizeof(UInt32));
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(pixels, width, height,
                                                 bitsPerComponent, bytesPerRow, colorSpace,
                                                 kCGImageAlphaPremultipliedLast|kCGBitmapByteOrder32Big);
    
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), inputCGImage);
    
    CGColorSpaceRelease(colorSpace);
    CGContextRelease(context);
    
#define Mask8(x) ( (x) & 0xFF )
#define R(x) ( Mask8(x) )
#define G(x) ( Mask8(x >> 8 ) )
#define B(x) ( Mask8(x >> 16) )
    
    // 2. Iterate and log!
    NSLog(@"Brightness of image:");
    UInt32 * currentPixel = pixels;
    UInt32 sumColor = 0;
    double valueToSum;
    double sumTest = 0.0;
    for (NSUInteger j = 0; j < height; j++) {
        for (NSUInteger i = 0; i < width; i++) {
            
               
            
            UInt32 color = *currentPixel;
            double maxx = 60;
            printf("%3.0f ", (R(color)+G(color)+B(color))/3.0);
            double test =(R(color)+G(color)+B(color))/3.0;
            if(test < maxx) {
                valueToSum = 0;
               // *currentPixel = 0;
                //color = *currentPixel;

            }
            else{
                valueToSum = test;
            }
            //printf("%3.0f ", (R(color)+G(color)+B(color))/3.0);

            currentPixel++;
        sumTest = valueToSum + sumTest;
        }
        
        sumColor = *currentPixel + sumColor;
        printf("\n");
            }
    NSLog(@"The summed brightness in the aperture is %f.", (double)sumTest); //(unsigned int)sumColor);
    free(pixels);
    return sumTest;
}

//-(CLLocationCoordinate2D) getLocation{
 //   CLLocationManager *locationManager = [[CLLocationManager alloc] init] ;
 //   locationManager.delegate = self;
 //   locationManager.desiredAccuracy = kCLLocationAccuracyBest;
 //   locationManager.distanceFilter = kCLDistanceFilterNone;
 //   [locationManager startUpdatingLocation];
 //   CLLocation *location = [locationManager location];
 //   CLLocationCoordinate2D coordinate = [location coordinate];
    
 //   return coordinate;/
//}



double getAOD(*CLLocationManager locManager, double sumTest) {
    
    //locationManager = [[CLLocationManager alloc] init];
    //locationManager.delegate = self;
    //NSNumber* AOD = [[NSNumber alloc] initWithFloat:1.0];
        //int interestingNumber = [someObject getAOD:sumColor];
    //3. SBS ALIS 2014
    //Use Brightness to assess solar attenuation
    //3.a
    float correctSunDist = 0;
    float beta = 0;
    NSDateFormatter *df = [NSDateFormatter new];
    [df setDateFormat:@"dd MM yyyy"];       //Remove the time part
    NSString *someDate = @"01 01 2014";
    NSString *TodayString = [df stringFromDate:[NSDate date]];
    NSString *TargetDateString = someDate;
    NSTimeInterval time = [[df dateFromString:TargetDateString] timeIntervalSinceDate:[df dateFromString:TodayString]];
    //[df release];
    int days = abs(time / 60 / 60/ 24);
    NSCalendar *gregorianCal = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *dateComps = [gregorianCal components: (NSHourCalendarUnit | NSMinuteCalendarUnit) fromDate:[NSDate date]];
    // Then use it
    //[dateComps minute];
    //[dateComps hour];
    
    NSDate *sourceDate = [NSDate dateWithTimeIntervalSinceNow:3600 * 24 * 60];
    NSTimeZone* destinationTimeZone = [NSTimeZone systemTimeZone];
    float timeZoneOffset = [destinationTimeZone secondsFromGMTForDate:sourceDate] / 3600.0;

   //tempPos = [[CLLocation alloc] latitude:valueLat longitude:valueLon];
    float latitude = locManager.location.coordinate.latitude;
    float longitude = locManager.location.coordinate.longitude;
    
    beta = 2 * M_PI * days / 365;
    correctSunDist = 1.00011 + 0.034221 * cos(beta) + 0.001280 * sin(beta) + 0.000719 * cos(2 * beta) + 0.000077 * sin(2 * beta);
    int v_o_550 = 1100000000;   //placeholder right now, not right value
    double y = (2 * M_PI / 365) * (days - 1 + ([dateComps hour] -12)/24);
    double eqtime = 229.18 * (0.000075 + 0.001868 * cos(y) - 0.032077 * sin(y) - 0.014615 * cos(2 * y) - 0.040849 * sin(2*y));
    double declin = 0.006918 - 0.399912 * cos(y) + 0.070257 * sin(y) - 0.006758 * cos(2*y) + 0.000907 * sin(2*y) - 0.002697 * cos(3*y)+ 0.00148 * sin(3*y);
    
    double time_offset = eqtime - 4 * longitude + 60 * timeZoneOffset;
    double tst = [dateComps hour] * 60 + [dateComps minute] + time_offset;
    double hourAngle = (tst/4 - 180)*M_PI/180;           //%radians
    double zenithAngle = acos(sin(latitude*M_PI/180) * sin(declin*M_PI/180) + cos(latitude*M_PI/180) * cos(declin*M_PI/180) * cos(hourAngle));
    double airMass = abs(1/cos(zenithAngle));
    double aerosolOpticalDepth = (-1 * airMass) * log(sumTest * correctSunDist / v_o_550);
    
#undef R
#undef G
#undef B
    return aerosolOpticalDepth;    
}

double getAirMass(double sumTest) {
 //   CLLocationManager *locationManager;

    float correctSunDist = 0;
    float beta = 0;
    NSDateFormatter *df = [NSDateFormatter new];
    [df setDateFormat:@"dd MM yyyy"];       //Remove the time part
    NSString *someDate = @"01 01 2014";
    NSString *TodayString = [df stringFromDate:[NSDate date]];
    NSString *TargetDateString = someDate;
    NSTimeInterval time = [[df dateFromString:TargetDateString] timeIntervalSinceDate:[df dateFromString:TodayString]];
    //[df release];
    int days = abs(time / 60 / 60/ 24);
    NSCalendar *gregorianCal = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *dateComps = [gregorianCal components: (NSHourCalendarUnit | NSMinuteCalendarUnit) fromDate:[NSDate date]];
    // Then use it
    //[dateComps minute];
    //[dateComps hour];
    
    NSDate *sourceDate = [NSDate dateWithTimeIntervalSinceNow:3600 * 24 * 60];
    NSTimeZone* destinationTimeZone = [NSTimeZone systemTimeZone];
    float timeZoneOffset = [destinationTimeZone secondsFromGMTForDate:sourceDate] / 3600.0;
    
    
    
    float latitude = locationManager.location.coordinate.latitude;
    float longitude = self.locationManager.location.coordinate.longitude;
    
    beta = 2 * M_PI * days / 365;
    correctSunDist = 1.00011 + 0.034221 * cos(beta) + 0.001280 * sin(beta) + 0.000719 * cos(2 * beta) + 0.000077 * sin(2 * beta);
    double y = (2 * M_PI / 365) * (days - 1 + ([dateComps hour] -12)/24);
    double eqtime = 229.18 * (0.000075 + 0.001868 * cos(y) - 0.032077 * sin(y) - 0.014615 * cos(2 * y) - 0.040849 * sin(2*y));
    double declin = 0.006918 - 0.399912 * cos(y) + 0.070257 * sin(y) - 0.006758 * cos(2*y) + 0.000907 * sin(2*y) - 0.002697 * cos(3*y)+ 0.00148 * sin(3*y); //radians
    
    double time_offset = eqtime - 4 * longitude + 60 * timeZoneOffset;
    double tst = [dateComps hour] * 60 + [dateComps minute] + time_offset;
    double hourAngle = (tst/4 - 180)*M_PI/180;           //%radians
    double zenithAngle = acos(sin(latitude*M_PI/180) * sin(declin) + cos(latitude*M_PI/180) * cos(declin) * cos(hourAngle));
    double airMass = abs(1/cos(zenithAngle));
    return airMass;
}

NSString* getAQI(double aerosolOpticalDepth) {
    double PBL = 0.8;       //km
    double humid = .51;
    double PM2p5 = exp(humid)*aerosolOpticalDepth*PBL;
    NSString *AQI;
    if  (PM2p5 <= 50) {
        NSString *AQI =@"Good";
    }
    if (PM2p5 >50 &&    PM2p5 <= 75) {
        NSString *AQI =@"Poor";
    }
    if (PM2p5 >75 &&    PM2p5 <= 100) {
        NSString *AQI =@"Severe";
    }
    if (PM2p5 >100){
        NSString *AQI =@"Toxic";
    }
    return AQI;
}


NSString* getTime(double sumTest) {
    NSDateFormatter *df = [NSDateFormatter new];
    [df setDateFormat:@"yyyy-MM-dd HH:mm:ss Z"];
    NSString *TodayString = [df stringFromDate:[NSDate date] ];
    return TodayString;
}


#pragma mark - Protocol Conformance

- (void)imageProcessorFinishedProcessingWithImage:(UIImage *)outputImage {
    self.workingImage = outputImage;
    self.imageView.image = outputImage;
}

//Segue stuff
-(void)prepareForSegue:(UIStoryboardSegue *)segue  sender:(id)sender{
    
    SecondViewController *transferViewController = segue.destinationViewController;

    NSLog(@"prepareForSegue: %@", segue.identifier);
    if([segue.identifier isEqualToString:@"resultsSegue"])
    {
        transferViewController.aodText=getAOD(x); //@"0.01"; // &(aerosolOpticalDepth);  //@"-1.0";
       // transferViewController.aodRaw=x;
        transferViewController.airMass=getAirMass(x);
       transferViewController.timeText=getTime(x);
        transferViewController.aqiText=getAQI(getAOD(x));
    }/*else if([segue.identifier isEqualToString:@"johnSegue"]){
        
    }*/
    
}
@end
