//
//  SecondViewController.h
//  test
//
//  Created by Strong, Shadrian B. on 7/22/14.
//  Copyright (c) 2014 ALIS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface SecondViewController : UIViewController 
//@property (nonatomic) double AOD;
@property (strong,nonatomic) IBOutlet UILabel *AOD;
@property (strong,nonatomic) IBOutlet UILabel *Attenuate;
@property (strong,nonatomic) IBOutlet UILabel *AIRMASS;
@property (strong,nonatomic) IBOutlet UILabel *AQI;
@property (strong,nonatomic) IBOutlet UILabel *timeNow;

@property (nonatomic)           double aodText;
@property (nonatomic)           UInt32 aodRaw;
@property (nonatomic)           double airMass;

@property (strong, nonatomic)          NSString *attenText;
@property (strong, nonatomic)          NSString *aqiText;
@property (strong, nonatomic)          NSString* timeText;
- (IBAction)startOver:(id)sender;
//@property (nonatomic) double aerosolOpticalDepth;
- (IBAction)postToFacebook:(id)sender;

//@property (strong, nonatomic) IBOutlet MKMapView *mapView;
//- (IBAction)changeMapType:(id)sender;


@end
