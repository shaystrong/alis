//
//  TableViewController.m
//  ALIS
//
//  Created by Strong, Shadrian B. on 10/2/14.
//  Copyright (c) 2014 ALIS. All rights reserved.
//
#import "ArchiveTableViewController.h"
#import <Foundation/Foundation.h>
@interface ArchiveTableViewController ()
@end

@implementation ArchiveTableViewController
{
    NSArray *recipes;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Initialize table data
    recipes = [NSArray arrayWithObjects:@"Egg Benedict", @"Mushroom Risotto", @"Full Breakfast", @"Hamburger", @"Ham and Egg Sandwich", @"Creme Brelee", @"White Chocolate Donut", @"Starbucks Coffee", @"Vegetable Curry", @"Instant Noodle with Egg", @"Noodle with BBQ Pork", @"Japanese Noodle with Pork", @"Green Tea", @"Thai Shrimp Cake", @"Angry Birds Cake", @"Ham and Cheese Panini", nil];
}

@end
